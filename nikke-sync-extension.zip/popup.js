"use strict";
(() => {
  // extension/protocol.ts
  var ORIGINS = ["http://127.0.0.1:5187", "http://localhost:5187", "https://masanori-spec.github.io"];

  // extension/popup.ts
  async function setup() {
    document.querySelector("h1").textContent = `NIKKE OL / \u8AAD\u53D6\u540C\u671F v${chrome.runtime.getManifest().version}`;
    const tabs = await chrome.tabs.query({ url: "https://www.blablalink.com/*" }), settings = await chrome.storage.local.get(["allowedOrigins", "selectedTabId"]);
    const select = document.querySelector("#tab"), allow = document.querySelector("#allow");
    allow.checked = Array.isArray(settings.allowedOrigins) && ORIGINS.every((o) => settings.allowedOrigins.includes(o));
    tabs.filter((t) => !t.incognito).forEach((t) => {
      const option = document.createElement("option");
      option.value = String(t.id);
      option.textContent = t.title ?? "BlaBlaLink";
      select.append(option);
    });
    if (settings.selectedTabId) select.value = String(settings.selectedTabId);
    document.querySelector("#save").addEventListener("click", async () => {
      await chrome.storage.local.set({ allowedOrigins: allow.checked ? ORIGINS : [], selectedTabId: Number(select.value) });
      document.querySelector("#status").textContent = "\u4FDD\u5B58\u3057\u307E\u3057\u305F\u3002\u96FB\u5353\u30DA\u30FC\u30B8\u3092\u518D\u8AAD\u307F\u8FBC\u307F\u3057\u3066\u540C\u671F\u3067\u304D\u307E\u3059\u3002";
    });
  }
  setup();
})();
