"use strict";
(() => {
  // src/data/blablalink-public-mappings.json
  var blablalink_public_mappings_default = {
    source: "Public unauthenticated CDN JSON",
    characterIdMapUrl: "https://sg-tools-cdn.blablalink.com/kx-19/bc64a706accd3c7ec1f9a9f2afd8f1bc.json",
    optionMapUrl: "https://sg-tools-cdn.blablalink.com/mx-94/801c63a8e02044db79f3081e706fcb55.json",
    nameCodeToResourceId: {
      "5001": "102",
      "5002": "140",
      "5003": "210",
      "5004": "191",
      "5005": "90",
      "5006": "160",
      "5007": "170",
      "5008": "270",
      "5009": "271",
      "5010": "142",
      "5011": "82",
      "5012": "220",
      "5013": "231",
      "5014": "150",
      "5015": "22",
      "5016": "30",
      "5017": "32",
      "5018": "70",
      "5019": "71",
      "5020": "72",
      "5021": "80",
      "5022": "91",
      "5023": "92",
      "5024": "101",
      "5025": "110",
      "5026": "130",
      "5027": "131",
      "5028": "141",
      "5029": "171",
      "5030": "172",
      "5031": "180",
      "5032": "181",
      "5033": "190",
      "5034": "200",
      "5035": "201",
      "5036": "202",
      "5037": "212",
      "5038": "241",
      "5039": "242",
      "5040": "221",
      "5041": "222",
      "5042": "230",
      "5043": "232",
      "1019": "290",
      "1020": "111",
      "3004": "240",
      "1007": "40",
      "1010": "100",
      "1012": "282",
      "1021": "281",
      "1022": "112",
      "5045": "280",
      "5044": "260",
      "5046": "310",
      "5048": "321",
      "5049": "272",
      "5050": "311",
      "5051": "312",
      "5053": "361",
      "5054": "381",
      "5055": "400",
      "5056": "261",
      "5059": "401",
      "5061": "233",
      "5064": "132",
      "5065": "330",
      "5066": "352",
      "5068": "380",
      "5069": "392",
      "5070": "432",
      "5071": "14",
      "5074": "430",
      "5075": "431",
      "5077": "391",
      "5078": "402",
      "5079": "350",
      "5081": "192",
      "5082": "33",
      "5085": "121",
      "5087": "203",
      "5088": "390",
      "5089": "800",
      "5090": "801",
      "5092": "382",
      "5097": "15",
      "5098": "353",
      "5094": "810",
      "5095": "811",
      "5099": "450",
      "5100": "451",
      "5101": "470",
      "5102": "224",
      "5103": "194",
      "5104": "62",
      "5105": "225",
      "5106": "313",
      "5107": "500",
      "5108": "820",
      "5109": "821",
      "5110": "43",
      "5111": "550",
      "5112": "501",
      "5113": "314",
      "5114": "195",
      "5115": "551",
      "5116": "283",
      "5117": "284",
      "5118": "830",
      "5119": "831",
      "5120": "832",
      "5121": "403",
      "5122": "580",
      "5123": "226",
      "5124": "511",
      "5125": "514",
      "5126": "411",
      "5127": "183",
      "5128": "182",
      "5129": "16",
      "5130": "354",
      "5131": "355",
      "5132": "834",
      "5133": "835",
      "5134": "412",
      "5135": "520",
      "5136": "521",
      "5137": "513",
      "5138": "162",
      "5139": "590",
      "5140": "581",
      "5141": "41",
      "5142": "850",
      "5143": "851",
      "5144": "532",
      "5145": "234",
      "5146": "502",
      "5147": "93",
      "5148": "94",
      "5149": "95",
      "5150": "143",
      "5151": "315",
      "5152": "840",
      "5153": "841",
      "5154": "23",
      "5155": "223",
      "5156": "262",
      "5157": "331",
      "5158": "74",
      "5159": "75",
      "5160": "73",
      "5161": "471",
      "5162": "582",
      "5163": "316",
      "5164": "860",
      "5165": "861",
      "5166": "113",
      "5167": "583",
      "5168": "620",
      "5169": "17",
      "5170": "18",
      "5171": "441",
      "5172": "600",
      "5173": "601",
      "5174": "570",
      "5175": "515",
      "5176": "322",
      "5177": "103",
      "5178": "105",
      "5179": "870",
      "5180": "871",
      "5181": "104",
      "5182": "404",
      "5183": "405",
      "3001": "10",
      "3002": "11",
      "3003": "20",
      "3005": "12",
      "3006": "161",
      "3009": "120",
      "3010": "291",
      "3007": "60",
      "3008": "61",
      "3011": "193",
      "3012": "802",
      "5063": "351",
      "5096": "812",
      "3013": "822",
      "3014": "833",
      "3015": "836",
      "3016": "852",
      "3017": "842",
      "3018": "862",
      "3019": "872",
      "1013": "300",
      "1014": "301",
      "1015": "302",
      "1016": "303",
      "1017": "304",
      "1018": "305",
      "1025": "306",
      "1024": "307",
      "1023": "308"
    },
    optionGroups: [
      {
        id: 10,
        description_localkey: "\u300C\u653B\u6483\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 1e3,
        state_effect_id_list: [
          9310101,
          9310102,
          9310103,
          9310104,
          9310105
        ]
      },
      {
        id: 11,
        description_localkey: "\u300C\u56DE\u5FA9\u5897\u52A0\u300D",
        state_effect_group_id: 2e3,
        state_effect_id_list: [
          9310201,
          9310202,
          9310203,
          9310204,
          9310205
        ]
      },
      {
        id: 20,
        description_localkey: "\u300C\u547D\u4E2D\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 3e3,
        state_effect_id_list: [
          9310301,
          9310302,
          9310303,
          9310304,
          9310305
        ]
      },
      {
        id: 1001001,
        description_localkey: "\u300C\u6709\u5229\u30B3\u30FC\u30C9\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100100,
        state_effect_id_list: [
          7000501,
          7000502,
          7000503,
          7000504,
          7000505
        ]
      },
      {
        id: 1001002,
        description_localkey: "\u300C\u6709\u5229\u30B3\u30FC\u30C9\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100100,
        state_effect_id_list: [
          7000506,
          7000507,
          7000508,
          7000509,
          7000510
        ]
      },
      {
        id: 1001003,
        description_localkey: "\u300C\u6709\u5229\u30B3\u30FC\u30C9\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100100,
        state_effect_id_list: [
          7000511,
          7000512,
          7000513,
          7000514,
          7000515
        ]
      },
      {
        id: 1002001,
        description_localkey: "\u300C\u547D\u4E2D\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100200,
        state_effect_id_list: [
          7000601,
          7000602,
          7000603,
          7000604,
          7000605
        ]
      },
      {
        id: 1002002,
        description_localkey: "\u300C\u547D\u4E2D\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100200,
        state_effect_id_list: [
          7000606,
          7000607,
          7000608,
          7000609,
          7000610
        ]
      },
      {
        id: 1002003,
        description_localkey: "\u300C\u547D\u4E2D\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100200,
        state_effect_id_list: [
          7000611,
          7000612,
          7000613,
          7000614,
          7000615
        ]
      },
      {
        id: 1003001,
        description_localkey: "\u300C\u6700\u5927\u88C5\u5F3E\u6570\u5897\u52A0\u300D",
        state_effect_group_id: 100300,
        state_effect_id_list: [
          7000701,
          7000702,
          7000703,
          7000704,
          7000705
        ]
      },
      {
        id: 1003002,
        description_localkey: "\u300C\u6700\u5927\u88C5\u5F3E\u6570\u5897\u52A0\u300D",
        state_effect_group_id: 100300,
        state_effect_id_list: [
          7000706,
          7000707,
          7000708,
          7000709,
          7000710
        ]
      },
      {
        id: 1003003,
        description_localkey: "\u300C\u6700\u5927\u88C5\u5F3E\u6570\u5897\u52A0\u300D",
        state_effect_group_id: 100300,
        state_effect_id_list: [
          7000711,
          7000712,
          7000713,
          7000714,
          7000715
        ]
      },
      {
        id: 1004001,
        description_localkey: "\u300C\u653B\u6483\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100400,
        state_effect_id_list: [
          7000801,
          7000802,
          7000803,
          7000804,
          7000805
        ]
      },
      {
        id: 1004002,
        description_localkey: "\u300C\u653B\u6483\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100400,
        state_effect_id_list: [
          7000806,
          7000807,
          7000808,
          7000809,
          7000810
        ]
      },
      {
        id: 1004003,
        description_localkey: "\u300C\u653B\u6483\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100400,
        state_effect_id_list: [
          7000811,
          7000812,
          7000813,
          7000814,
          7000815
        ]
      },
      {
        id: 1005001,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100500,
        state_effect_id_list: [
          7000901,
          7000902,
          7000903,
          7000904,
          7000905
        ]
      },
      {
        id: 1005002,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100500,
        state_effect_id_list: [
          7000906,
          7000907,
          7000908,
          7000909,
          7000910
        ]
      },
      {
        id: 1005003,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100500,
        state_effect_id_list: [
          7000911,
          7000912,
          7000913,
          7000914,
          7000915
        ]
      },
      {
        id: 1006001,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u901F\u5EA6\u5897\u52A0\u300D",
        state_effect_group_id: 100600,
        state_effect_id_list: [
          7001001,
          7001002,
          7001003,
          7001004,
          7001005
        ]
      },
      {
        id: 1006002,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u901F\u5EA6\u5897\u52A0\u300D",
        state_effect_group_id: 100600,
        state_effect_id_list: [
          7001006,
          7001007,
          7001008,
          7001009,
          7001010
        ]
      },
      {
        id: 1006003,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u901F\u5EA6\u5897\u52A0\u300D",
        state_effect_group_id: 100600,
        state_effect_id_list: [
          7001011,
          7001012,
          7001013,
          7001014,
          7001015
        ]
      },
      {
        id: 1007001,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u78BA\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100700,
        state_effect_id_list: [
          7001101,
          7001102,
          7001103,
          7001104,
          7001105
        ]
      },
      {
        id: 1007002,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u78BA\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100700,
        state_effect_id_list: [
          7001106,
          7001107,
          7001108,
          7001109,
          7001110
        ]
      },
      {
        id: 1007003,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u78BA\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100700,
        state_effect_id_list: [
          7001111,
          7001112,
          7001113,
          7001114,
          7001115
        ]
      },
      {
        id: 1008001,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100800,
        state_effect_id_list: [
          7001201,
          7001202,
          7001203,
          7001204,
          7001205
        ]
      },
      {
        id: 1008002,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100800,
        state_effect_id_list: [
          7001206,
          7001207,
          7001208,
          7001209,
          7001210
        ]
      },
      {
        id: 1008003,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100800,
        state_effect_id_list: [
          7001211,
          7001212,
          7001213,
          7001214,
          7001215
        ]
      },
      {
        id: 1009001,
        description_localkey: "\u300C\u9632\u5FA1\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100900,
        state_effect_id_list: [
          7001301,
          7001302,
          7001303,
          7001304,
          7001305
        ]
      },
      {
        id: 1009002,
        description_localkey: "\u300C\u9632\u5FA1\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100900,
        state_effect_id_list: [
          7001306,
          7001307,
          7001308,
          7001309,
          7001310
        ]
      },
      {
        id: 1009003,
        description_localkey: "\u300C\u9632\u5FA1\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100900,
        state_effect_id_list: [
          7001311,
          7001312,
          7001313,
          7001314,
          7001315
        ]
      }
    ]
  };

  // src/data/overload.ts
  var EFFECTS = ["element_damage", "accuracy", "max_ammo", "attack", "charge_damage", "charge_speed", "critical_rate", "critical_damage", "defense"];
  var common = [477, 547, 618, 688, 759, 829, 900, 970, 1040, 1111, 1181, 1252, 1322, 1393, 1463];
  var VALUES = {
    element_damage: [954, 1094, 1234, 1375, 1515, 1655, 1795, 1935, 2075, 2215, 2356, 2496, 2636, 2776, 2916],
    accuracy: common,
    max_ammo: [2784, 3195, 3606, 4017, 4428, 4839, 5250, 5660, 6071, 6482, 6893, 7304, 7715, 8126, 8537],
    attack: common,
    charge_damage: common,
    charge_speed: [198, 228, 257, 286, 316, 345, 375, 404, 433, 463, 492, 521, 551, 580, 609],
    critical_rate: [230, 264, 298, 332, 366, 400, 435, 469, 503, 537, 570, 605, 639, 673, 707],
    critical_damage: [664, 762, 860, 958, 1056, 1154, 1252, 1350, 1448, 1546, 1644, 1742, 1840, 1938, 2036],
    defense: common
  };
  var PARTS = ["head", "torso", "arm", "leg"];

  // src/features/blablalink/normalize.ts
  var types = { element_damage: ["IncElementDmg"], accuracy: ["StatAccuracyCircle", "OnHitRatio"], max_ammo: ["StatAmmoLoad", "StatAmmo"], attack: ["StatAtk"], charge_damage: ["StatChargeDamage"], charge_speed: ["StatChargeTime"], critical_rate: ["StatCritical"], critical_damage: ["StatCriticalDamage"], defense: ["StatDef", "IncHurtDef"] };
  var optionMap = /* @__PURE__ */ new Map();
  for (const row of blablalink_public_mappings_default.optionGroups) {
    const idx = (row.state_effect_group_id - 100100) / 100, bucket = row.id % 10;
    if (!Number.isInteger(idx) || idx < 0 || idx >= 9 || bucket < 1 || bucket > 3) continue;
    row.state_effect_id_list.forEach((id, index) => optionMap.set(String(id), { effect: EFFECTS[idx], level: (bucket - 1) * 5 + index + 1 }));
  }
  function resourceForNameCode(code) {
    return blablalink_public_mappings_default.nameCodeToResourceId[String(code)] ?? null;
  }
  function nameCodeForResource(resourceId) {
    const matches = Object.entries(blablalink_public_mappings_default.nameCodeToResourceId).filter(([, id]) => id === resourceId);
    if (matches.length !== 1) throw new Error("MASTER_MAPPING_MISSING");
    return Number(matches[0][0]);
  }
  function assertApiCode(raw) {
    if (!raw || typeof raw !== "object") throw new Error("SCHEMA_CHANGED");
    const x = raw;
    if (x.code === 300001) throw new Error("LOGIN_REQUIRED");
    if (x.code !== 0) throw new Error("API_REJECTED");
    return x;
  }
  function assertSuccess(raw) {
    const x = assertApiCode(raw);
    if (!x.data || typeof x.data !== "object") throw new Error("SCHEMA_CHANGED");
    return x.data;
  }
  function gameOpenId(value) {
    if (typeof value !== "string" || !/^29080-[0-9]+$/.test(value)) throw new Error("WRONG_GAME_REGION");
    return value.slice(value.indexOf("-") + 1);
  }
  function unknown(status = "unknown", optionId = null) {
    return { status, effect: null, level: null, value: null, locked: null, optionId };
  }
  function normalizeDetails(raw, resourceId) {
    const data = assertSuccess(raw), code = nameCodeForResource(resourceId);
    if (!Array.isArray(data.character_details) || !Array.isArray(data.state_effects)) throw new Error("SCHEMA_CHANGED");
    const records = data.character_details.filter((x) => x && typeof x === "object" && x.name_code === code);
    if (records.length !== 1) throw new Error("CHARACTER_NOT_RETURNED");
    const record = records[0];
    const effects = /* @__PURE__ */ new Map(), conflicts = /* @__PURE__ */ new Set();
    for (const row of data.state_effects) {
      if (!row || typeof row !== "object" || !["number", "string"].includes(typeof row.id)) continue;
      const id = String(row.id);
      if (effects.has(id) && JSON.stringify(effects.get(id)) !== JSON.stringify(row)) conflicts.add(id);
      effects.set(id, row);
    }
    const equipment = {}, equipmentState = {};
    for (const p of PARTS) {
      const tier = record[`${p}_equip_tier`], tid = record[`${p}_equip_tid`];
      const state = tier === 10 ? "overload" : tid === 0 ? "unequipped" : typeof tier === "number" && tier > 0 && tier < 10 ? "non_overload" : "unknown";
      equipmentState[p] = state;
      equipment[p] = [1, 2, 3].map((n) => {
        if (state === "non_overload" || state === "unequipped") return unknown("not_applicable");
        const id = record[`${p}_equip_option${n}_id`];
        if (id === 0 || id === "0") return state === "overload" ? unknown("empty") : unknown();
        if (!(typeof id === "number" && Number.isSafeInteger(id) && id > 0 || typeof id === "string" && /^[1-9][0-9]*$/.test(id))) return unknown();
        const key = String(id), mapped = optionMap.get(key), effect = effects.get(key);
        if (!mapped || !effect || conflicts.has(key) || !Array.isArray(effect.function_details) || effect.function_details.length !== 1) return unknown("unresolved", key);
        const fn = effect.function_details[0];
        if (!fn || !types[mapped.effect].includes(fn.function_type) || !Number.isSafeInteger(fn.function_value)) return unknown("unresolved", key);
        const value = Math.abs(fn.function_value);
        if (value !== VALUES[mapped.effect][mapped.level - 1]) return unknown("unresolved", key);
        return { status: "present", effect: mapped.effect, level: mapped.level, value, locked: null, lockSource: "api", optionId: key };
      });
    }
    return { resourceId, equipment, equipmentState, lockFields: [] };
  }

  // src/features/blablalink/roster.ts
  var integer = (v) => typeof v === "number" && Number.isSafeInteger(v) && v >= 0 && v <= 1e9 ? v : null;
  function normalizeOwned(rows) {
    if (!Array.isArray(rows) || rows.length > 1e3) throw new Error("SCHEMA_CHANGED");
    const seen = /* @__PURE__ */ new Set();
    return rows.flatMap((row) => {
      const resourceId = resourceForNameCode(row?.name_code);
      if (!resourceId) return [];
      if (seen.has(resourceId)) throw new Error("SCHEMA_CHANGED");
      seen.add(resourceId);
      return [{ resourceId, combat: integer(row.combat), level: integer(row.lv), grade: integer(row.grade), core: integer(row.core) }];
    });
  }

  // extension/isolated.ts
  var BASE = "https://api.blablalink.com/api/";
  var API = { login: ["POST", "user/CheckLogin"], self: ["POST", "ugc/proxy/standalonesite/User/GetUserInfoNew"], role: ["GET", "game/proxy/Game/GetSavedRoleInfo"], characters: ["POST", "game/proxy/Game/GetUserCharacters"], details: ["POST", "game/proxy/Game/GetUserCharacterDetails"] };
  var HEADERS = { "Content-Type": "application/json", "Accept": "application/json, text/plain, */*", "X-Channel-Type": "2", "X-Language": "ja", "X-Common-Params": JSON.stringify({ game_id: "16", area_id: "global", source: "pc_web", intl_game_id: "29080", language: "ja", env: "prod" }) };
  async function request(endpoint, body = {}) {
    const [method, path] = API[endpoint];
    for (let attempt = 0; attempt < 3; attempt++) {
      const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 2e4);
      try {
        const response = await fetch(BASE + path, { method, headers: HEADERS, credentials: "include", redirect: "error", cache: "no-store", signal: controller.signal, ...method === "POST" ? { body: JSON.stringify(body) } : {} });
        if (response.status === 429 && attempt < 2) {
          const seconds = Number(response.headers.get("Retry-After"));
          await new Promise((r) => setTimeout(r, Math.min(1e4, Number.isFinite(seconds) && seconds > 0 ? seconds * 1e3 : 1e3 * 2 ** attempt)));
          continue;
        }
        if (response.status === 401 || response.status === 403) throw new Error("LOGIN_REQUIRED");
        if (!response.ok) throw new Error(response.status === 429 ? "RATE_LIMITED" : "NETWORK_ERROR");
        const raw = await response.json();
        assertApiCode(raw);
        if (endpoint !== "login") assertSuccess(raw);
        return raw;
      } finally {
        clearTimeout(timer);
      }
    }
    throw new Error("RATE_LIMITED");
  }
  async function identity() {
    const self = assertSuccess(await request("self")), role = assertSuccess(await request("role"));
    const info = self.info, roleInfo = role.role_info;
    const openid = gameOpenId(info?.intl_openid ?? self.intl_openid), rawArea = roleInfo?.area_id;
    if (!roleInfo) throw new Error("ROLE_NOT_BOUND");
    const area = typeof rawArea === "number" ? rawArea : typeof rawArea === "string" && /^[1-9][0-9]{0,9}$/.test(rawArea) ? Number(rawArea) : NaN;
    if (!Number.isSafeInteger(area) || area <= 0) throw new Error("ROLE_SCHEMA_CHANGED");
    return { openid, area };
  }
  async function run(resourceId) {
    if (location.origin !== "https://www.blablalink.com" || window.top !== window) throw new Error("WRONG_ORIGIN");
    const nameCode = resourceId === "all" ? null : nameCodeForResource(resourceId);
    await request("login");
    const before = await identity();
    const body = { intl_open_id: before.openid, nikke_area_id: before.area };
    const owned = assertSuccess(await request("characters", body));
    if (!Array.isArray(owned.characters)) throw new Error("SCHEMA_CHANGED");
    if (resourceId === "all") {
      const growth = normalizeOwned(owned.characters), characters = [];
      for (let i = 0; i < growth.length; i += 200) {
        const batch = growth.slice(i, i + 200), details = await request("details", { ...body, name_codes: batch.map((e) => nameCodeForResource(e.resourceId)) });
        for (const entry of batch) characters.push({ ...entry, character: normalizeDetails(details, entry.resourceId) });
      }
      const after2 = await identity();
      if (before.openid !== after2.openid || before.area !== after2.area) throw new Error("ACCOUNT_CHANGED");
      return { ok: true, source: "authenticated-api", fetchedAt: (/* @__PURE__ */ new Date()).toISOString(), characters, skipped: owned.characters.length - growth.length };
    }
    if (!owned.characters.some((x) => x?.name_code === nameCode)) throw new Error("CHARACTER_NOT_OWNED");
    const character = normalizeDetails(await request("details", { ...body, name_codes: [nameCode] }), resourceId);
    const after = await identity();
    if (before.openid !== after.openid || before.area !== after.area) throw new Error("ACCOUNT_CHANGED");
    return { ok: true, source: "authenticated-api", fetchedAt: (/* @__PURE__ */ new Date()).toISOString(), character };
  }
  globalThis.__nikkeOlRead = async (id) => {
    try {
      return await run(id);
    } catch (error) {
      const code = error instanceof Error ? error.message : "";
      return { ok: false, error: ["LOGIN_REQUIRED", "ROLE_NOT_BOUND", "ROLE_SCHEMA_CHANGED", "ACCOUNT_CHANGED", "CHARACTER_NOT_OWNED", "CHARACTER_NOT_RETURNED", "SCHEMA_CHANGED", "MASTER_MAPPING_MISSING", "WRONG_GAME_REGION", "RATE_LIMITED", "API_REJECTED"].includes(code) ? code : "NETWORK_ERROR" };
    }
  };
})();
