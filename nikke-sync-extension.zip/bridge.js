"use strict";
(() => {
  // extension/protocol.ts
  var ORIGINS = ["http://127.0.0.1:5187", "http://localhost:5187", "https://masanori-spec.github.io"];
  function allowedOrigin(url) {
    try {
      if (!url) return false;
      const u = new URL(url);
      return ORIGINS.includes(u.origin) && (u.origin !== "https://masanori-spec.github.io" || u.pathname === "/nikke-overload" || u.pathname.startsWith("/nikke-overload/"));
    } catch {
      return false;
    }
  }

  // extension/bridge.ts
  if (allowedOrigin(location.href) && window.top === window) {
    const pending = /* @__PURE__ */ new Map();
    chrome.runtime.onMessage.addListener((message, sender, reply) => {
      if (sender.id !== chrome.runtime.id || message?.type !== "NIKKE_SYNC_CALLER_CHECK") return false;
      const ok = typeof message.requestId === "string" && pending.get(message.requestId) === location.href && allowedOrigin(location.href) && window.top === window;
      reply({ ok, requestId: message.requestId });
      return false;
    });
    const signal = async () => {
      try {
        const status = await chrome.runtime.sendMessage({ type: "NIKKE_EXTENSION_STATUS" });
        window.dispatchEvent(new CustomEvent("nikke-extension-ready", { detail: { version: status?.version ?? "0.1.0", allowed: status?.allowed === true } }));
      } catch {
        window.dispatchEvent(new CustomEvent("nikke-extension-disconnected"));
      }
    };
    window.addEventListener("nikke-extension-ping", signal);
    signal();
    document.addEventListener("click", async (event) => {
      if (!event.isTrusted) return;
      const target = event.target.closest("[data-sync-character], [data-sync-all]");
      if (!target) return;
      const all = target.dataset.syncAll === "true", resourceId = all ? "all" : target.dataset.syncCharacter;
      if (!all && (!resourceId || !/^\d{1,8}$/.test(resourceId))) return;
      const requestId = crypto.randomUUID(), url = location.href;
      pending.set(requestId, url);
      try {
        const response = await chrome.runtime.sendMessage({ type: all ? "SYNC_ALL_REQUEST" : "SYNC_OL_REQUEST", schemaVersion: 1, requestId, resourceId });
        window.dispatchEvent(new CustomEvent("nikke-sync-result", { detail: location.href === url ? response : { ok: false, error: "CALLER_TAB_CHANGED" } }));
      } catch {
        window.dispatchEvent(new CustomEvent("nikke-sync-result", { detail: { ok: false, error: "EXTENSION_DISCONNECTED" } }));
      } finally {
        pending.delete(requestId);
      }
    }, true);
  }
})();
