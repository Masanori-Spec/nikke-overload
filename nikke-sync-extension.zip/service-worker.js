"use strict";
(() => {
  // src/data/blablalink-public-mappings.json
  var blablalink_public_mappings_default = {
    source: "Public unauthenticated CDN JSON",
    characterIdMapUrl: "https://sg-tools-cdn.blablalink.com/kx-19/bc64a706accd3c7ec1f9a9f2afd8f1bc.json",
    optionMapUrl: "https://sg-tools-cdn.blablalink.com/mx-94/801c63a8e02044db79f3081e706fcb55.json",
    nameCodeToResourceId: {
      "5001": "102",
      "5002": "140",
      "5003": "210",
      "5004": "191",
      "5005": "90",
      "5006": "160",
      "5007": "170",
      "5008": "270",
      "5009": "271",
      "5010": "142",
      "5011": "82",
      "5012": "220",
      "5013": "231",
      "5014": "150",
      "5015": "22",
      "5016": "30",
      "5017": "32",
      "5018": "70",
      "5019": "71",
      "5020": "72",
      "5021": "80",
      "5022": "91",
      "5023": "92",
      "5024": "101",
      "5025": "110",
      "5026": "130",
      "5027": "131",
      "5028": "141",
      "5029": "171",
      "5030": "172",
      "5031": "180",
      "5032": "181",
      "5033": "190",
      "5034": "200",
      "5035": "201",
      "5036": "202",
      "5037": "212",
      "5038": "241",
      "5039": "242",
      "5040": "221",
      "5041": "222",
      "5042": "230",
      "5043": "232",
      "1019": "290",
      "1020": "111",
      "3004": "240",
      "1007": "40",
      "1010": "100",
      "1012": "282",
      "1021": "281",
      "1022": "112",
      "5045": "280",
      "5044": "260",
      "5046": "310",
      "5048": "321",
      "5049": "272",
      "5050": "311",
      "5051": "312",
      "5053": "361",
      "5054": "381",
      "5055": "400",
      "5056": "261",
      "5059": "401",
      "5061": "233",
      "5064": "132",
      "5065": "330",
      "5066": "352",
      "5068": "380",
      "5069": "392",
      "5070": "432",
      "5071": "14",
      "5074": "430",
      "5075": "431",
      "5077": "391",
      "5078": "402",
      "5079": "350",
      "5081": "192",
      "5082": "33",
      "5085": "121",
      "5087": "203",
      "5088": "390",
      "5089": "800",
      "5090": "801",
      "5092": "382",
      "5097": "15",
      "5098": "353",
      "5094": "810",
      "5095": "811",
      "5099": "450",
      "5100": "451",
      "5101": "470",
      "5102": "224",
      "5103": "194",
      "5104": "62",
      "5105": "225",
      "5106": "313",
      "5107": "500",
      "5108": "820",
      "5109": "821",
      "5110": "43",
      "5111": "550",
      "5112": "501",
      "5113": "314",
      "5114": "195",
      "5115": "551",
      "5116": "283",
      "5117": "284",
      "5118": "830",
      "5119": "831",
      "5120": "832",
      "5121": "403",
      "5122": "580",
      "5123": "226",
      "5124": "511",
      "5125": "514",
      "5126": "411",
      "5127": "183",
      "5128": "182",
      "5129": "16",
      "5130": "354",
      "5131": "355",
      "5132": "834",
      "5133": "835",
      "5134": "412",
      "5135": "520",
      "5136": "521",
      "5137": "513",
      "5138": "162",
      "5139": "590",
      "5140": "581",
      "5141": "41",
      "5142": "850",
      "5143": "851",
      "5144": "532",
      "5145": "234",
      "5146": "502",
      "5147": "93",
      "5148": "94",
      "5149": "95",
      "5150": "143",
      "5151": "315",
      "5152": "840",
      "5153": "841",
      "5154": "23",
      "5155": "223",
      "5156": "262",
      "5157": "331",
      "5158": "74",
      "5159": "75",
      "5160": "73",
      "5161": "471",
      "5162": "582",
      "5163": "316",
      "5164": "860",
      "5165": "861",
      "5166": "113",
      "5167": "583",
      "5168": "620",
      "5169": "17",
      "5170": "18",
      "5171": "441",
      "5172": "600",
      "5173": "601",
      "5174": "570",
      "5175": "515",
      "5176": "322",
      "5177": "103",
      "5178": "105",
      "5179": "870",
      "5180": "871",
      "5181": "104",
      "5182": "404",
      "5183": "405",
      "3001": "10",
      "3002": "11",
      "3003": "20",
      "3005": "12",
      "3006": "161",
      "3009": "120",
      "3010": "291",
      "3007": "60",
      "3008": "61",
      "3011": "193",
      "3012": "802",
      "5063": "351",
      "5096": "812",
      "3013": "822",
      "3014": "833",
      "3015": "836",
      "3016": "852",
      "3017": "842",
      "3018": "862",
      "3019": "872",
      "1013": "300",
      "1014": "301",
      "1015": "302",
      "1016": "303",
      "1017": "304",
      "1018": "305",
      "1025": "306",
      "1024": "307",
      "1023": "308"
    },
    optionGroups: [
      {
        id: 10,
        description_localkey: "\u300C\u653B\u6483\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 1e3,
        state_effect_id_list: [
          9310101,
          9310102,
          9310103,
          9310104,
          9310105
        ]
      },
      {
        id: 11,
        description_localkey: "\u300C\u56DE\u5FA9\u5897\u52A0\u300D",
        state_effect_group_id: 2e3,
        state_effect_id_list: [
          9310201,
          9310202,
          9310203,
          9310204,
          9310205
        ]
      },
      {
        id: 20,
        description_localkey: "\u300C\u547D\u4E2D\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 3e3,
        state_effect_id_list: [
          9310301,
          9310302,
          9310303,
          9310304,
          9310305
        ]
      },
      {
        id: 1001001,
        description_localkey: "\u300C\u6709\u5229\u30B3\u30FC\u30C9\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100100,
        state_effect_id_list: [
          7000501,
          7000502,
          7000503,
          7000504,
          7000505
        ]
      },
      {
        id: 1001002,
        description_localkey: "\u300C\u6709\u5229\u30B3\u30FC\u30C9\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100100,
        state_effect_id_list: [
          7000506,
          7000507,
          7000508,
          7000509,
          7000510
        ]
      },
      {
        id: 1001003,
        description_localkey: "\u300C\u6709\u5229\u30B3\u30FC\u30C9\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100100,
        state_effect_id_list: [
          7000511,
          7000512,
          7000513,
          7000514,
          7000515
        ]
      },
      {
        id: 1002001,
        description_localkey: "\u300C\u547D\u4E2D\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100200,
        state_effect_id_list: [
          7000601,
          7000602,
          7000603,
          7000604,
          7000605
        ]
      },
      {
        id: 1002002,
        description_localkey: "\u300C\u547D\u4E2D\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100200,
        state_effect_id_list: [
          7000606,
          7000607,
          7000608,
          7000609,
          7000610
        ]
      },
      {
        id: 1002003,
        description_localkey: "\u300C\u547D\u4E2D\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100200,
        state_effect_id_list: [
          7000611,
          7000612,
          7000613,
          7000614,
          7000615
        ]
      },
      {
        id: 1003001,
        description_localkey: "\u300C\u6700\u5927\u88C5\u5F3E\u6570\u5897\u52A0\u300D",
        state_effect_group_id: 100300,
        state_effect_id_list: [
          7000701,
          7000702,
          7000703,
          7000704,
          7000705
        ]
      },
      {
        id: 1003002,
        description_localkey: "\u300C\u6700\u5927\u88C5\u5F3E\u6570\u5897\u52A0\u300D",
        state_effect_group_id: 100300,
        state_effect_id_list: [
          7000706,
          7000707,
          7000708,
          7000709,
          7000710
        ]
      },
      {
        id: 1003003,
        description_localkey: "\u300C\u6700\u5927\u88C5\u5F3E\u6570\u5897\u52A0\u300D",
        state_effect_group_id: 100300,
        state_effect_id_list: [
          7000711,
          7000712,
          7000713,
          7000714,
          7000715
        ]
      },
      {
        id: 1004001,
        description_localkey: "\u300C\u653B\u6483\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100400,
        state_effect_id_list: [
          7000801,
          7000802,
          7000803,
          7000804,
          7000805
        ]
      },
      {
        id: 1004002,
        description_localkey: "\u300C\u653B\u6483\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100400,
        state_effect_id_list: [
          7000806,
          7000807,
          7000808,
          7000809,
          7000810
        ]
      },
      {
        id: 1004003,
        description_localkey: "\u300C\u653B\u6483\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100400,
        state_effect_id_list: [
          7000811,
          7000812,
          7000813,
          7000814,
          7000815
        ]
      },
      {
        id: 1005001,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100500,
        state_effect_id_list: [
          7000901,
          7000902,
          7000903,
          7000904,
          7000905
        ]
      },
      {
        id: 1005002,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100500,
        state_effect_id_list: [
          7000906,
          7000907,
          7000908,
          7000909,
          7000910
        ]
      },
      {
        id: 1005003,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100500,
        state_effect_id_list: [
          7000911,
          7000912,
          7000913,
          7000914,
          7000915
        ]
      },
      {
        id: 1006001,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u901F\u5EA6\u5897\u52A0\u300D",
        state_effect_group_id: 100600,
        state_effect_id_list: [
          7001001,
          7001002,
          7001003,
          7001004,
          7001005
        ]
      },
      {
        id: 1006002,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u901F\u5EA6\u5897\u52A0\u300D",
        state_effect_group_id: 100600,
        state_effect_id_list: [
          7001006,
          7001007,
          7001008,
          7001009,
          7001010
        ]
      },
      {
        id: 1006003,
        description_localkey: "\u300C\u30C1\u30E3\u30FC\u30B8\u901F\u5EA6\u5897\u52A0\u300D",
        state_effect_group_id: 100600,
        state_effect_id_list: [
          7001011,
          7001012,
          7001013,
          7001014,
          7001015
        ]
      },
      {
        id: 1007001,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u78BA\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100700,
        state_effect_id_list: [
          7001101,
          7001102,
          7001103,
          7001104,
          7001105
        ]
      },
      {
        id: 1007002,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u78BA\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100700,
        state_effect_id_list: [
          7001106,
          7001107,
          7001108,
          7001109,
          7001110
        ]
      },
      {
        id: 1007003,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u78BA\u7387\u5897\u52A0\u300D",
        state_effect_group_id: 100700,
        state_effect_id_list: [
          7001111,
          7001112,
          7001113,
          7001114,
          7001115
        ]
      },
      {
        id: 1008001,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100800,
        state_effect_id_list: [
          7001201,
          7001202,
          7001203,
          7001204,
          7001205
        ]
      },
      {
        id: 1008002,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100800,
        state_effect_id_list: [
          7001206,
          7001207,
          7001208,
          7001209,
          7001210
        ]
      },
      {
        id: 1008003,
        description_localkey: "\u300C\u30AF\u30EA\u30C6\u30A3\u30AB\u30EB\u30C0\u30E1\u30FC\u30B8\u5897\u52A0\u300D",
        state_effect_group_id: 100800,
        state_effect_id_list: [
          7001211,
          7001212,
          7001213,
          7001214,
          7001215
        ]
      },
      {
        id: 1009001,
        description_localkey: "\u300C\u9632\u5FA1\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100900,
        state_effect_id_list: [
          7001301,
          7001302,
          7001303,
          7001304,
          7001305
        ]
      },
      {
        id: 1009002,
        description_localkey: "\u300C\u9632\u5FA1\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100900,
        state_effect_id_list: [
          7001306,
          7001307,
          7001308,
          7001309,
          7001310
        ]
      },
      {
        id: 1009003,
        description_localkey: "\u300C\u9632\u5FA1\u529B\u5897\u52A0\u300D",
        state_effect_group_id: 100900,
        state_effect_id_list: [
          7001311,
          7001312,
          7001313,
          7001314,
          7001315
        ]
      }
    ]
  };

  // src/data/overload.ts
  var EFFECTS = ["element_damage", "accuracy", "max_ammo", "attack", "charge_damage", "charge_speed", "critical_rate", "critical_damage", "defense"];
  var common = [477, 547, 618, 688, 759, 829, 900, 970, 1040, 1111, 1181, 1252, 1322, 1393, 1463];
  var VALUES = {
    element_damage: [954, 1094, 1234, 1375, 1515, 1655, 1795, 1935, 2075, 2215, 2356, 2496, 2636, 2776, 2916],
    accuracy: common,
    max_ammo: [2784, 3195, 3606, 4017, 4428, 4839, 5250, 5660, 6071, 6482, 6893, 7304, 7715, 8126, 8537],
    attack: common,
    charge_damage: common,
    charge_speed: [198, 228, 257, 286, 316, 345, 375, 404, 433, 463, 492, 521, 551, 580, 609],
    critical_rate: [230, 264, 298, 332, 366, 400, 435, 469, 503, 537, 570, 605, 639, 673, 707],
    critical_damage: [664, 762, 860, 958, 1056, 1154, 1252, 1350, 1448, 1546, 1644, 1742, 1840, 1938, 2036],
    defense: common
  };
  var PARTS = ["head", "torso", "arm", "leg"];

  // src/features/blablalink/normalize.ts
  var optionMap = /* @__PURE__ */ new Map();
  for (const row of blablalink_public_mappings_default.optionGroups) {
    const idx = (row.state_effect_group_id - 100100) / 100, bucket = row.id % 10;
    if (!Number.isInteger(idx) || idx < 0 || idx >= 9 || bucket < 1 || bucket > 3) continue;
    row.state_effect_id_list.forEach((id, index) => optionMap.set(String(id), { effect: EFFECTS[idx], level: (bucket - 1) * 5 + index + 1 }));
  }
  function sanitizeCharacter(raw) {
    if (!raw || !/^\d{1,8}$/.test(raw.resourceId)) throw new Error("SCHEMA_CHANGED");
    const equipment = {}, equipmentState = {};
    for (const p of PARTS) {
      if (!Array.isArray(raw.equipment?.[p]) || raw.equipment[p].length !== 3) throw new Error("SCHEMA_CHANGED");
      equipmentState[p] = ["overload", "non_overload", "unequipped", "unknown"].includes(raw.equipmentState[p]) ? raw.equipmentState[p] : "unknown";
      equipment[p] = raw.equipment[p].map((s) => {
        if (!["present", "empty", "unknown", "unresolved", "not_applicable"].includes(s.status)) throw new Error("SCHEMA_CHANGED");
        if (s.status === "present" && (!s.effect || !EFFECTS.includes(s.effect) || !s.level || VALUES[s.effect][s.level - 1] !== s.value)) throw new Error("SCHEMA_CHANGED");
        return { status: s.status, effect: s.status === "present" ? s.effect : null, level: s.status === "present" ? s.level : null, value: s.status === "present" ? s.value : null, locked: null, lockSource: "api", optionId: typeof s.optionId === "string" && /^\d{1,20}$/.test(s.optionId) ? s.optionId : null };
      });
    }
    return { resourceId: raw.resourceId, equipment, equipmentState, lockFields: [] };
  }

  // src/features/blablalink/roster.ts
  var integer = (v) => typeof v === "number" && Number.isSafeInteger(v) && v >= 0 && v <= 1e9 ? v : null;
  function sanitizeRoster(raw) {
    if (!raw || !Array.isArray(raw.characters) || raw.characters.length > 1e3 || typeof raw.fetchedAt !== "string" || !Number.isFinite(Date.parse(raw.fetchedAt))) throw new Error("SCHEMA_CHANGED");
    const seen = /* @__PURE__ */ new Set();
    return { fetchedAt: raw.fetchedAt, skipped: integer(raw.skipped) ?? 0, characters: raw.characters.map((e) => {
      const character = sanitizeCharacter(e.character);
      if (e.resourceId !== character.resourceId || seen.has(e.resourceId)) throw new Error("SCHEMA_CHANGED");
      seen.add(e.resourceId);
      return { resourceId: e.resourceId, combat: integer(e.combat), level: integer(e.level), grade: integer(e.grade), core: integer(e.core), character };
    }) };
  }

  // extension/protocol.ts
  var ORIGINS = ["http://127.0.0.1:5187", "http://localhost:5187", "https://masanori-spec.github.io"];
  function allowedOrigin(url) {
    try {
      if (!url) return false;
      const u = new URL(url);
      return ORIGINS.includes(u.origin) && (u.origin !== "https://masanori-spec.github.io" || u.pathname === "/nikke-overload" || u.pathname.startsWith("/nikke-overload/"));
    } catch {
      return false;
    }
  }
  function validateRequest(message) {
    if (!message || typeof message !== "object" || JSON.stringify(message).length > 1024) throw new Error("INVALID_REQUEST");
    const m = message;
    if (Object.keys(m).some((k) => !["type", "schemaVersion", "requestId", "resourceId"].includes(k)) || !["SYNC_OL_REQUEST", "SYNC_ALL_REQUEST"].includes(m.type) || m.schemaVersion !== 1 || typeof m.requestId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(m.requestId) || typeof m.resourceId !== "string" || !(m.type === "SYNC_ALL_REQUEST" ? m.resourceId === "all" : /^\d{1,8}$/.test(m.resourceId))) throw new Error("INVALID_REQUEST");
    return m;
  }

  // extension/service-worker.ts
  var jobs = /* @__PURE__ */ new Set();
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const run = async () => {
      if (!allowedOrigin(sender.url) || sender.frameId !== 0 || !sender.tab?.id || sender.tab.incognito) throw new Error("ORIGIN_REJECTED");
      if (message?.type === "NIKKE_EXTENSION_STATUS" && Object.keys(message).length === 1) {
        const settings2 = await chrome.storage.local.get(["allowedOrigins"]);
        return { ok: true, version: chrome.runtime.getManifest().version, allowed: Array.isArray(settings2.allowedOrigins) && settings2.allowedOrigins.includes(new URL(sender.url).origin) };
      }
      const request = validateRequest(message), origin = new URL(sender.url).origin;
      const settings = await chrome.storage.local.get(["allowedOrigins", "selectedTabId"]);
      if (request.type === "SYNC_ALL_REQUEST") {
        const approval = await chrome.tabs.sendMessage(sender.tab.id, { type: "NIKKE_SYNC_CALLER_CHECK", requestId: request.requestId }, sender.documentId ? { documentId: sender.documentId } : { frameId: 0 }).catch(() => null);
        if (approval?.ok !== true || approval.requestId !== request.requestId) throw new Error("CALLER_TAB_CHANGED");
        settings.allowedOrigins = [.../* @__PURE__ */ new Set([...Array.isArray(settings.allowedOrigins) ? settings.allowedOrigins : [], origin])];
        await chrome.storage.local.set({ allowedOrigins: settings.allowedOrigins });
      }
      if (!Array.isArray(settings.allowedOrigins) || !settings.allowedOrigins.includes(origin)) throw new Error("CONNECTION_NOT_ALLOWED");
      const caller = sender.tab.id;
      if (jobs.has(caller)) throw new Error("BUSY");
      jobs.add(caller);
      try {
        const tabs = (await chrome.tabs.query({ url: "https://www.blablalink.com/*" })).filter((t) => !t.incognito && new URL(t.url).origin === "https://www.blablalink.com");
        const tab = tabs.length === 1 ? tabs[0] : tabs.find((t) => t.id === settings.selectedTabId);
        if (!tab?.id) throw new Error(tabs.length ? "SELECT_BLABLALINK_TAB" : "BLABLALINK_TAB_REQUIRED");
        const started = Date.now(), originalUrl = tab.url;
        const injected = await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] }, world: "ISOLATED", files: ["isolated.js"] });
        const documentId = injected[0]?.documentId;
        const target = documentId ? { tabId: tab.id, documentIds: [documentId] } : { tabId: tab.id, frameIds: [0] };
        const results = await chrome.scripting.executeScript({ target, world: "ISOLATED", func: async (id) => {
          const context = globalThis;
          const reader = context.__nikkeOlRead, url = location.href;
          if (typeof reader !== "function") return { ok: false, error: "SOURCE_DOCUMENT_CHANGED" };
          const result = await reader(id);
          if (context.__nikkeOlRead !== reader || location.href !== url) return { ok: false, error: "SOURCE_DOCUMENT_CHANGED" };
          return result;
        }, args: [request.resourceId] });
        if (Date.now() - started > 18e4) throw new Error("JOB_EXPIRED");
        const now = await chrome.tabs.get(tab.id);
        if (now.url !== originalUrl) throw new Error("SOURCE_TAB_CHANGED");
        const callerCheck = await chrome.tabs.sendMessage(caller, { type: "NIKKE_SYNC_CALLER_CHECK", requestId: request.requestId }, sender.documentId ? { documentId: sender.documentId } : { frameId: 0 }).catch(() => null);
        if (callerCheck?.ok !== true || callerCheck.requestId !== request.requestId) throw new Error("CALLER_TAB_CHANGED");
        const raw = results[0]?.result;
        if (!raw || raw.ok !== true) throw new Error(raw?.error ?? "SCHEMA_CHANGED");
        if (request.type === "SYNC_ALL_REQUEST") return { ok: true, type: "SYNC_ALL_RESULT", schemaVersion: 1, requestId: request.requestId, source: "authenticated-api", ...sanitizeRoster(raw) };
        return { ok: true, type: "SYNC_OL_RESULT", schemaVersion: 1, requestId: request.requestId, source: "authenticated-api", fetchedAt: raw.fetchedAt, character: sanitizeCharacter(raw.character) };
      } finally {
        jobs.delete(caller);
      }
    };
    run().then(sendResponse).catch((e) => sendResponse({ ok: false, error: /^[A-Z_]+$/.test(e.message) ? e.message : "SYNC_FAILED" }));
    return true;
  });
})();
